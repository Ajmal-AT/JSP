package com.crud.hope.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.hope.DAO.EmpDAO;
import com.crud.hope.DTO.Emp;

@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<a href='addemp.html'>Add New Employees</a>");
		out.println("<center><h1> Update Employee Details </h1></center>");
		String n=request.getParameter("id");
		int id = Integer.parseInt(n);
		List<Emp> lp = EmpDAO.EditGetEmployees(id);
		for(Emp c:lp){
		out.print("<br><center> <form action='UpdateServlet?id="+c.getId()+"' method='post'> ");
		out.print("<br> <table> ");
		out.print("<tr><th>Name :</th><td><input type='text' name='name' value='"+c.getName()+"'></tr>"+
				"<tr><th>Password :</th><td><input type='password' name='psd' value='"+c.getPsd()+"'></tr> "+
				"<tr><th>Email :</th><td><input type='email' name='email' value='"+c.getEmail()+"'></tr> " +
				"<tr><th>Country :</th><td><select name=\"ctry\" style=\"width: 170px\">\r\n"
				+ "				<option>"+c.getCtry()+"  </option>\r\n"
				+ "				<option>INDIA</option>\r\n"
				+ "				<option>USA</option>\r\n"
				+ "				<option>CHINA</option>\r\n"
				+ "				<option>USA</option>\r\n"
				+ "				<option>CANADA</option>\r\n"
				+ "				<option>RUSSIA</option>\r\n"
				+ "				<option>UAE</option>\r\n"
				+ "				<option>Other</option>\r\n"
				+ "					</select></td></tr>"
				+"<tr> <th colspan='2'><input type='submit' value='Edit & Save Employee' ></th></tr>");
		}
		out.print("</table></center>");
	}

}
