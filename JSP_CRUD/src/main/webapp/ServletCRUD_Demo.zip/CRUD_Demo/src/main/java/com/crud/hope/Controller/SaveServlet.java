package com.crud.hope.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.hope.DAO.EmpDAO;
import com.crud.hope.DTO.Emp;

public class SaveServlet extends HttpServlet {
    	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out=res.getWriter();
		
		String name=req.getParameter("name");
		String psd=req.getParameter("psd");
		String email=req.getParameter("email");
		String ctry=req.getParameter("ctry");
		
		Emp e1=new Emp();
		e1.setName(name);
		e1.setPsd(psd);
		e1.setEmail(email);
		e1.setCtry(ctry);
		
		int sta=EmpDAO.AddEmployees(e1);
		
		if (sta>0) {
			RequestDispatcher red =req.getRequestDispatcher("addemp.html");
			red.include(req, res);
			out.print("Record Saved Successfully");
		}
		else {
			out.print("Sorry...! Unable to save the Record...");
		}
		out.close();
	}

}
