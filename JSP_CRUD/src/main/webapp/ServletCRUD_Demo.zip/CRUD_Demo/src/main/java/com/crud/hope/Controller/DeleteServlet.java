package com.crud.hope.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.hope.DAO.EmpDAO;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String n = request.getParameter("id");
		int id = Integer.parseInt(n);
		int sta=0;
		
		
		try {
			Connection con=EmpDAO.getConnection();
			PreparedStatement st = con.prepareStatement("Delete from hope_emp WHERE id="+id+"");
			System.out.println(st);
			sta=st.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e);
		}

		if (sta>0) {
			RequestDispatcher red =request.getRequestDispatcher("addemp.html");
			red.include(request, response);
			out.print("Record Delete Successfully");
		}
		else {
			out.print("Sorry...! Unable to Delete the Record...");
		}
		out.close();
		
	}

}
