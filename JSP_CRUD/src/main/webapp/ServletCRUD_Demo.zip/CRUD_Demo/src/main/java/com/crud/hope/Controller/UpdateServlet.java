package com.crud.hope.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.crud.hope.DAO.EmpDAO;
import com.crud.hope.DTO.Emp;

@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		String n = request.getParameter("id");
		int id = Integer.parseInt(n);
		
		String name = request.getParameter("name");
		String psd = request.getParameter("psd");
		String email = request.getParameter("email");
		String ctry = request.getParameter("ctry");
		
		Emp e1=new Emp();
		e1.setName(name);
		e1.setPsd(psd);
		e1.setEmail(email);
		e1.setCtry(ctry);
		
		int sta = EmpDAO.UpdateEmployees(e1, id);
		
		if (sta>0) {
			RequestDispatcher red =request.getRequestDispatcher("addemp.html");
			red.include(request, response);
			out.print("Record Update Successfully");
		}
		else {
			out.print("Sorry...! Unable to Update the Record...");
		}
		out.close();
	}

}
