create database hope_crud;
use hope_crud;

create table hope_emp(id int primary key auto_increment,name varchar(30),password varchar(20),email varchar(20),country varchar(20));
describe hope_emp;

select * from hope_emp;
DELETE FROM hope_emp WHERE id=7;
